<script setup>
import Banner from './Banner/index.vue'
import Brands from './Brands/index.vue'
import Products from './Products/index.vue'
</script>

<template>
  <Banner/>
  <Brands/>
  <Products/>
</template>

